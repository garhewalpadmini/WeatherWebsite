import React from "react";
import Weather from "./Weather/Weather";
import Data from "./Data/Data";

const App = () => {
  return(
    <>
        <Weather />

        {/* <Data /> */}
    </>
  );
}

export default App;