import React,{useState} from 'react'
const Data=()=>{
const Api = {
  key:'8ec2610e144222122bcbe2fcf705960d',
  base:'https://api.openweathermap.org/data/2.5/weather'
}
const[weather,setWeather]=useState({})
const[search,setSearch]=useState("")

function handleSearch(){
  fetch(`${api.base}?q=${search}&appid=${api.key}`)
  .then(res=>res.json())
  .then(d=>{setWeather(d)
  console.log(d);
})
}
  return (
    <div>
      <h1>Get Weather Info</h1>
      <section>
        <input type="text" placeholder="City name..."  onChange={(e) => setSearch(e.target.value)}/>
        <button onClick={handleSearch}>Search</button>
      </section>

      {(typeof weather.main != 'undefined')?(
        <div>
          <p>{weather.name}</p>
          <p>{weather.main.temp}</p>
          <p>{weather.weather[0].main}</p>
          <p>{weather.weather[0].description}</p>
        </div>
        
      ):(
       'not found'
      )}

    </div>
      

    
  )
}

export default Data