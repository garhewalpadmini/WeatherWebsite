import React, { useEffect, useState } from "react";
import "./Weather.css";

const Weather = () => {
  const [city, setCity] = useState();
  const [search, setSearch] = useState("Solapur");

  useEffect(() => {
    const fetchApi = async () => {
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${search}&units=matrix&appid=8ec2610e144222122bcbe2fcf705960d`;
      const responseData = fetch(url);
      const res = await (await responseData).json();
      // console.log(res)
      setCity(res.main);
      
    };

    fetchApi();
  }, [search]);

  return (
    <>
      <div className="MainSec">
        <div className="Card">
          <input
            type="text"
            onChange={(e) => {
              setSearch(e.target.value);
            }}
            id="searchBox"
          />

          {!city ? (
            <p>No data Found </p>
          ) : (
            <div className="Extradiv">
              <div className="StreetView">
                <i className="fa-solid fa-street-view"></i>
                <h1>{search}</h1>
              </div>

              <div className="temp">
                <h1>{city.temp}</h1>
              </div>

              <div className="LastSec">
                <h3>Min : 5.25 cel | Max : 5.25 cel</h3>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Weather;
